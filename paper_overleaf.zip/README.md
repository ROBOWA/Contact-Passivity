# Paper bundle — results section + figures

Drop-in material for Overleaf, generated entirely from the implemented PoC
and one coherent fresh dataset.

## Contents

- `main.tex` — standalone single-column wrapper: compiles the Results
  section on its own (set it as Overleaf's Main document). Contains a
  labeled stub setup section so all references resolve; for the full
  paper, skip it and `\input{results_section}` from your own main file.
- `results_section.tex` — the formal Results section (`\section{Results}`),
  organized around the four core selective-passivation comparisons:
  C0 vs C3 (why a filter), C1 vs C3 (model-work exemption), C2 vs C3
  (dedicated human port), and the C3 governor-off/on ablation. Includes a
  compact controller-roles table. Requires `graphicx`, `booktabs`,
  `amsmath`.
- `table_summary.tex` — supplementary complete-run metrics for C0--C3. The
  concise standalone report states the headline values in the text instead
  of including this dense table.
- `figs/fig1…fig8.pdf` — vector figures, numbered to match the
  compiled paper; `figS1`/`figS2` are the supplementary governor-on
  counterparts of Figs. 5 and 6 (not referenced from the LaTeX). Sized
  for a two-column layout (single column 3.4 in, `figure*` 7.0 in).
- `make_figures.py` — regenerates every figure and the table from the
  experiment logs (run from the repository root:
  `python paper/make_figures.py`).

## Data provenance (single coherent dataset)

All figures and the table are generated from `results_passivation_iter2/`,
produced by the implemented PoC via

```bash
python -m mujoco_sliding.experiments --all --sweep --governor-compare
```

The paper compares C0 (nominal), `C1_whole_port_qp` (whole-port
baseline), `C2_residual_qp` (residual-only), and `C3_dual_ledger_qp`
(proposed), plus the C3 reference-governor ablation. The
`C4_dual_ledger_safe_scalar` controller remains implemented and tested in
the repository as a diagnostic, but appears in no paper figure or table.
No iteration-1 data or mode names are used anywhere.

### Clipping convention

Some filter-behavior figures clip post-interaction intervals whose only
purpose is recovery (the governor figure always shows the complete
interaction and release). **Only evaluation and presentation are ever
clipped**: the simulations run the full duration, the control commands /
forces / ledger updates / saved logs are never clipped, and all
certificate quantities (ledger minima, violation counts) use the complete
runs.

## Overleaf import

Upload the folder contents to your project **root** (`main.tex` optional,
`results_section.tex`, `table_summary.tex`, `figs/`). For standalone
compilation set *Menu → Settings → Main document* to `main.tex`. For the
full paper, `\input{results_section}` from your main file; the narrow
figures use `\figwidth` (defaults to `\columnwidth`; predefine it for
single-column layouts as `main.tex` does). One placeholder remains:
`\ref{sec:task}` should point at your task-setup section.

## Known provenance limitation

The Results section describes the robust (iteration-2) constraint rows
(prediction-error-bounded lower power estimates, conditional certificate).
If your methods section still shows the older row formulas
(`min(0, ·) − δ_p`) or the old mode names, update it to match — see
`mujoco_sliding/passivity_qp.py` and the README section
"Selective-passivation layer" for the current formulation.
